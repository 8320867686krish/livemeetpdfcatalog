import HTMLFlipBook from "react-pageflip";

const PDFFlip = () => {
    return (
        <HTMLFlipBook width={700} height={800}>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/1000`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/1000`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`https://picsum.photos/150/700`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`${IMAGE_PREFIX}/images/watch.jpg`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`${IMAGE_PREFIX}/images/skincare.jpg`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`${IMAGE_PREFIX}/images/watch.jpg`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`${IMAGE_PREFIX}/images/food.jpg`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`${IMAGE_PREFIX}/images/skincare.jpg`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`${IMAGE_PREFIX}/images/watch.jpg`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`${IMAGE_PREFIX}/images/food.jpg`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`${IMAGE_PREFIX}/images/skincare.jpg`} alt="Image" /></div>
            <div className="demoPage"><img style={{ width: "100%", maxWidth: "100%", height: "100%" }} src={`${IMAGE_PREFIX}/images/watch.jpg`} alt="Image" /></div>
        </HTMLFlipBook>
    );
}

export default PDFFlip;