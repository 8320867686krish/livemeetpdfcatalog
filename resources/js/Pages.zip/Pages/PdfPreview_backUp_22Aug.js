// import axios from "axios";
import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { Button, AppProvider } from "@shopify/polaris";
import HTMLFlipBook from "react-pageflip";
import { ArrowLeftIcon, ArrowRightIcon } from "@shopify/polaris-icons";
import { decode as base64_decode, encode as base64_encode } from "base-64";
import "bootstrap/dist/css/bootstrap.min.css";
import parse from "html-react-parser";
import { fetchMethod } from "./helper";
const PdfPreview = (props = {}) => {
    // const location = useLocation();
    const [baseUriString, setBaseUriString] = useState("");
    const flipId = window.location.href.split("/").pop();
    const [pagesContent, setPagesContent] = useState([]);
    const [currentPage, setCurrentPage] = useState(0);
    const flipBookRef = useRef(null);
    const goToNextPage = () => {
        if (flipBookRef.current) {
            const newPage = currentPage + 1;
            if (newPage < pagesContent.length) {
                flipBookRef.current.pageFlip().flipNext();
                setCurrentPage(newPage);
            }
        }
    };
    const goToPreviousPage = () => {
        if (flipBookRef.current) {
            const newPage = currentPage - 1;
            if (newPage >= 0) {
                flipBookRef.current.pageFlip().flipPrev();
                setCurrentPage(newPage);
            }
        }
    };

    useEffect(() => {
        // Replace this with your actual fetch request
        if (pagesContent.length === 0) {
            getData();
        }
    }, [pagesContent]);

    function splitHtmlByDivId(htmlString) {
        // Use a regular expression to match divs with id patterns like "page_id", "page_1", "page_2", etc.
        const regex = /<div\s+id="page_id_\d+"[^>]*>(.*?)<\/div>/gs;
        let matches;
        const resultArray = [];

        while ((matches = regex.exec(htmlString)) !== null) {
            // Capture the entire div including its content
            resultArray.push(matches[0]);
        }

        return resultArray;
    }

    function combinePages(arr) {
        const combinedPages = [];

        arr.map((item) => {
            const existingPage = combinedPages.find(
                (page) => page.page === item.page
            );

            if (existingPage) {
                // Combine the HTML content if the page already exists
                existingPage.value += item.value;
            } else {
                // Add a new page if it doesn't exist
                combinedPages.push({ page: item.page, value: item.value });
            }
        });

        // Add wrapping <div> tags with zoom: 0.55 around each page's content
        combinedPages.forEach((page) => {
            page.value = `<div style="zoom: 0.55;">${page.value}</div>`;
        });

        // Sort by page number to ensure the pages are in order
        combinedPages.sort((a, b) => a.page.localeCompare(b.page));

        return combinedPages;
    }

    const getData = () => {
        // const getData = await fetchMethod(
        //     getMethodType,
        //     `https://b44a-103-56-183-234.ngrok-free.app/api/flipPdf/${flipId}`,
        //     // shopid
        // );
        // setPagesContent(getData);
        axios({
            url: window.location.origin + `/api/flipPdf/${flipId}`,
            method: "GET",
            responseType: "json",
        }).then(function (response) {
            const result = JSON.parse(response.data.data.flipHtml);

            setPagesContent(combinePages(result));
        });
    };

    return (
        <AppProvider
            theme=""
            style={{
                backgroundColor: "blue",
            }}
        >
            <div>
                <div className="mb-4 mt-3 text-center">
                    <button
                        onClick={() => goToPreviousPage()}
                        className="btn btn-primary"
                    >
                        Previous Page{" "}
                    </button>
                    <button
                        onClick={() => goToNextPage()}
                        className="btn btn-primary mx-2"
                    >
                        Next Page{" "}
                    </button>
                </div>
                <div
                    style={{
                        // height: "600px !important",
                        marginRight: "100px",
                        marginLeft: "100px",
                        // overflow:"revert-layer",
                        // backgroundColor: "blue",
                        // overflow:"scroll",
                        // position: "relative",
                        // transform :"scale(0.4)",
                    }}
                >
                    <HTMLFlipBook
                        // showCover={true}
                        ref={flipBookRef}
                        key={250}
                        usePortrait={true}
                        height={350}
                        showPageCorners={true}
                        width={300}
                        size="stretch"
                        maxShadowOpacity={0}
                        flippingTime={1500}
                        animation="flip"
                        startPage={0}
                        onChangePage={(page) => setCurrentPage(page)}
                        style={{
                            margin: "0 auto",
                            // boxShadow: `
                            //         rgba(0, 0, 0, 0.15) -10px 0px 20px,
                            //         rgba(0, 0, 0, 0.15) 10px 0px 20px,
                            //         rgba(0, 0, 0, 0.2) 0px 0px 10px,
                            //         rgba(0, 0, 0, 0.1) 0px 0px 20px
                            //     `,
                            // transform: "scale(0.5)",
                        }}
                    >
                        {pagesContent.map((content, index) => {
                            return (
                                <div
                                    // data-density="hard"
                                    className="demoPage"
                                    style={{
                                        width: "100%",
                                        maxWidth: "100%",
                                        height: "100px",
                                        maxHeight: "100px",
                                    }}
                                >
                                {parse(content.value)}
                                </div>
                            );
                        })}
                    </HTMLFlipBook>
                </div>
            </div>
        </AppProvider>
    );
};
export default PdfPreview;
