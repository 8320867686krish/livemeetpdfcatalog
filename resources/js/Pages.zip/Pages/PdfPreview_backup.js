// import axios from "axios";
import React, {
    useState,
    useEffect,
    useRef,
    useSyncExternalStore,
} from "react";
import { useLocation } from "react-router-dom";
import { Button, AppProvider } from "@shopify/polaris";
import HTMLFlipBook from "react-pageflip";
import { ArrowLeftIcon, ArrowRightIcon } from "@shopify/polaris-icons";
import { decode as base64_decode, encode as base64_encode } from "base-64";
import "bootstrap/dist/css/bootstrap.min.css";
import parse from "html-react-parser";
import { RotatingLines } from "react-loader-spinner";
import { fetchMethod } from "./helper";

const PdfPreview = (props = {}) => {
    // const location = useLocation();
    const [baseUriString, setBaseUriString] = useState("");
    const flipId = window.location.href.split("/").pop();
    const [pagesContent, setPagesContent] = useState([]);
    const [currentPage, setCurrentPage] = useState(0);
    const [loader, setLoader] = useState(true);
    const flipBookRef = useRef(null);

    const goToNextPage = () => {
        if (flipBookRef.current) {
            const newPage = currentPage + 2;
            if (newPage < pagesContent.length) {
                flipBookRef.current.pageFlip().flipNext();
                setCurrentPage(newPage);
            }
        }
    };

    const goToPreviousPage = () => {
        if (flipBookRef.current) {
            const newPage = currentPage - 1;
            if (newPage >= 0) {
                flipBookRef.current.pageFlip().flipPrev();
                setCurrentPage(newPage);
            }
        }
    };

    useEffect(() => {
        // Replace this with your actual fetch request
        if (pagesContent.length === 0) {
            setTimeout(() => {
                getData();
            }, 2000);
        }
    }, [pagesContent]);

    function splitHtmlByDivId(htmlString) {
        const regex = /<div\s+id="page_id_\d+"[^>]*>(.*?)<\/div>/gs;
        let matches;
        const resultArray = [];

        while ((matches = regex.exec(htmlString)) !== null) {
            resultArray.push(matches[0]);
        }

        return resultArray;
    }

    function combinePages(arr) {
        const combinedPages = [];

        arr.map((item) => {
            const existingPage = combinedPages.find(
                (page) => page.page === item.page
            );

            if (existingPage) {
                existingPage.value += item.value;
            } else {
                combinedPages.push({ page: item.page, value: item.value });
            }
        });

        return combinedPages;
    }

    const getData = () => {
        setLoader(true);
        console.log(
            "url : ",
            window.location.origin + `/api/flipPdf/${flipId}`
        );
        axios({
            url: window.location.origin + `/api/flipPdf/${flipId}`,
            method: "GET",
            responseType: "json",
        }).then(function (response) {
            const result = JSON.parse(response.data.data.flipHtml);
            setPagesContent(combinePages(result));
            setLoader(false);
        });
    };

    return (
        <AppProvider
            theme=""
            style={{
                backgroundColor: "blue",
            }}
        >
            {loader === true ? (
                <>
                    <div
                        style={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            height: "100vh",
                        }}
                    >
                        <center>
                            <RotatingLines
                                visible={true}
                                height="96"
                                width="96"
                                color="green"
                                strokeWidth="5"
                                animationDuration="0.75"
                                ariaLabel="rotating-lines-loading"
                                wrapperStyle={{}}
                                wrapperClass=""
                            />
                        </center>
                    </div>
                </>
            ) : (
                <>
                    <div>
                        <div className="mb-4 mt-3 text-center">
                            <button
                                onClick={() => goToPreviousPage()}
                                className={`btn ${
                                    currentPage <= 0
                                        ? "btn-secondary"
                                        : "btn-primary"
                                }`}
                                disabled={currentPage <= 0}
                            >
                                Previous Page
                            </button>
                            <button
                                onClick={() => goToNextPage()}
                                className={`btn ${
                                    currentPage >= pagesContent.length - 1
                                        ? "btn-secondary"
                                        : "btn-primary"
                                } mx-2`}
                                disabled={
                                    currentPage >= pagesContent.length - 2
                                }
                            >
                                Next Page
                            </button>
                        </div>
                        <div
                            style={{
                                marginRight: "100px",
                                marginLeft: "100px",
                            }}
                        >
                            <HTMLFlipBook
                                uncutPages="true"
                                showSwipeHint="true"
                                autoCenter={true}
                                ref={flipBookRef}
                                key={250}
                                usePortrait={true}
                                height={800}
                                showPageCorners={true}
                                width={300}
                                swipeDistance={100}
                                size="stretch"
                                maxShadowOpacity={0}
                                flippingTime={1500}
                                showCover={true}
                                animation="flip"
                                disableFlipByClick={true}
                                disableFlipByTouch={true}
                                startPage={0}
                                onFlip={(page) => {
                                    console.log("page : ", page.data);
                                    setCurrentPage(page.data);
                                }}
                                style={{
                                    margin: "0 auto",
                                }}
                            >
                                {pagesContent.map((content, index) => {
                                    return (
                                        <div
                                            data-density="hard"
                                            className="demoPage"
                                        >
                                            {parse(content.value)}
                                        </div>
                                    );
                                })}
                            </HTMLFlipBook>
                        </div>
                    </div>
                </>
            )}
        </AppProvider>
    );
};
export default PdfPreview;
